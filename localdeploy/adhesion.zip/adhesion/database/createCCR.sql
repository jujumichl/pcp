DROP DATABASE IF EXISTS `cerclecetest`;
CREATE DATABASE IF NOT EXISTS `cerclecetest` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci */;
USE `cerclecetest`;