<div style="margin-top:100px">
    2025-06-10 00:10 : intégration fichier YB : </br>
--- Erreur : ligne 100 : .boulor@ n'est une adresse mail correcte</br>
--- Erreur : ligne 120 : montant invalide</br>
--- Erreur : ligne 200 : nouvelle adhésion pour une personne existante dans la base</br>
2025-06-10 00:15 : intégration données HelloAsso.</br>
2025-06-10 00:15 : Création manuelle de la personne julien.michelin@free.fr par Juliett.</br>

</div>