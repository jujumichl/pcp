<?php
session_start();
print  "</br></br></br></br></br></br></br></br></br>DOnnées". json_decode($_SESSION['personList']) ;;