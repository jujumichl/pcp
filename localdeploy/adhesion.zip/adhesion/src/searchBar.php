<div class="input-group w-25 float-end">
      <input
        type="text"
        class="form-control"
        placeholder="Recherche"
      />
      <span class="input-group-text" id="basic-addon2">
        <img src="./images/search.svg" alt="Search">
    </span>
</div>