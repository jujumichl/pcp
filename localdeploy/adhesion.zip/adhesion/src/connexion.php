<div class="position-absolute top-50 start-50 translate-middle" style="color:#eeeeed">
    <div class="card sm mb-3">
        <h1 class="card-header">
            Connexion :
        </h1> 
        <div class="card-body">
            <form id="formConnexion" method="POST" action="index.php?uc=selec">
                <div class="mb-3">
                <label for="formUtilisateur" class="form-label">Nom d'utilisateur :</label>
                <input type="text" class="form-control" id="formUtilisateur" placeholder="Entrer votre nom d'utilisateur">
                </div>   
                <label for="mdp" class="form-label">Mot de passe : </label>
                <input type="password" id="mdp" class="form-control" aria-describedby="passwordHelpBlock">
                <div id="passwordHelpBlock" class="form-text">
                Votre mot de passe fait au moins 8 caractères de longs, contient des lettres, des nombres et des caractères spéciaux.
                </div>
                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                    <button class="btn btn-success me-md-2" type="submit">Envoyer</button>
                    <button class="btn btn-danger" type="clear">Annuler</button>
                </div>
            </form>
        </div>
    </div>
</div>