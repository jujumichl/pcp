<div style="margin-top:100px">
    <div class="row">
    <div class="h5" style="color:#d07d29">intégration HelloAsso</div>
        <hr/>
        <!-- <div class="col-6">
            <div class="input-group w-100 float-end">
                <input
                    type="text"
                    class="form-control"
                    placeholder="Recherche"
                />
                <span class="input-group-text" id="basic-addon2">
                    <img src="./images/search.svg" alt="Search">
                </span>
            </div>
        </div> -->
        <div class="col-6">
        <button type="button" class="btn btn-secondary">Lancer l'intégration</button>
            <!-- <div class="dropdown">
                <a class="btn btn-outline-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
                    Tableaux
                </a>

                <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                    <li><a class="dropdown-item" href="#">Participants par activité</a></li>
                    <li><a class="dropdown-item" href="#">Répartition Homme/Femme</a></li>
                    <li><a class="dropdown-item" href="#">Répartition par age</a></li>

                    <li><a class="dropdown-item" href="#"></a></li>
                </ul>
            </div> -->
        </div>





    </div>
</div>