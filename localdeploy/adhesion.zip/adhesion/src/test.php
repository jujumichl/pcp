<?php
print date('/Y');