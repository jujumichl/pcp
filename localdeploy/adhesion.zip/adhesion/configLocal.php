<?php
$db = 'cerclecetest';
$dbHost = 'localhost';
$dbUser = 'root';
$dbMdp = '';